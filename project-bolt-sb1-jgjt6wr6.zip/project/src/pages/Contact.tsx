import React from 'react';
import { Mail, Phone, MapPin } from 'lucide-react';

const Contact = () => {
  return (
    <main className="pt-24 pb-16">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="max-w-3xl mx-auto text-center mb-12">
          <h1 className="text-4xl font-serif mb-4">Contact Us</h1>
          <p className="text-gray-600">
            We'd love to hear from you. Get in touch with us for any questions or concerns.
          </p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8 mb-12">
          <div className="text-center p-6">
            <Mail className="h-8 w-8 text-green-800 mx-auto mb-4" />
            <h3 className="font-medium mb-2">Email</h3>
            <p className="text-gray-600">support@jasmineshop.com</p>
          </div>
          <div className="text-center p-6">
            <Phone className="h-8 w-8 text-green-800 mx-auto mb-4" />
            <h3 className="font-medium mb-2">WhatsApp</h3>
            <a 
              href="https://wa.me/213657525137" 
              target="_blank" 
              rel="noopener noreferrer"
              className="text-gray-600 hover:text-green-800"
            >
              +213 657 52 51 37
            </a>
          </div>
          <div className="text-center p-6">
            <MapPin className="h-8 w-8 text-green-800 mx-auto mb-4" />
            <h3 className="font-medium mb-2">Location</h3>
            <p className="text-gray-600">Khemis el khechna, Boumerdes</p>
          </div>
        </div>

        <div className="max-w-2xl mx-auto">
          <div className="text-center mb-8">
            <h2 className="text-2xl font-serif mb-4">Social Media</h2>
            <div className="space-y-2">
              <p>
                <span className="font-medium">Facebook:</span>{' '}
                <a 
                  href="https://www.facebook.com/Jasminshop96" 
                  target="_blank" 
                  rel="noopener noreferrer"
                  className="text-green-800 hover:underline"
                >
                  Jasminshop96
                </a>
              </p>
              <p>
                <span className="font-medium">Instagram:</span>{' '}
                <a 
                  href="https://www.instagram.com/jasmine_shop_96" 
                  target="_blank" 
                  rel="noopener noreferrer"
                  className="text-green-800 hover:underline"
                >
                  @jasmine_shop_96
                </a>
              </p>
            </div>
          </div>

          <form className="space-y-6">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div>
                <label htmlFor="name" className="block text-sm font-medium text-gray-700 mb-1">
                  Name
                </label>
                <input
                  type="text"
                  id="name"
                  className="w-full border border-gray-200 p-2 focus:outline-none focus:ring-2 focus:ring-green-800"
                />
              </div>
              <div>
                <label htmlFor="email" className="block text-sm font-medium text-gray-700 mb-1">
                  Email
                </label>
                <input
                  type="email"
                  id="email"
                  className="w-full border border-gray-200 p-2 focus:outline-none focus:ring-2 focus:ring-green-800"
                />
              </div>
            </div>
            <div>
              <label htmlFor="subject" className="block text-sm font-medium text-gray-700 mb-1">
                Subject
              </label>
              <input
                type="text"
                id="subject"
                className="w-full border border-gray-200 p-2 focus:outline-none focus:ring-2 focus:ring-green-800"
              />
            </div>
            <div>
              <label htmlFor="message" className="block text-sm font-medium text-gray-700 mb-1">
                Message
              </label>
              <textarea
                id="message"
                rows={6}
                className="w-full border border-gray-200 p-2 focus:outline-none focus:ring-2 focus:ring-green-800"
              ></textarea>
            </div>
            <button
              type="submit"
              className="w-full bg-green-800 text-white py-3 hover:bg-green-900 transition-colors"
            >
              Send Message
            </button>
          </form>
        </div>

        <div className="mt-12 bg-gray-50 p-8 text-center">
          <h2 className="text-2xl font-serif mb-4">FAQ</h2>
          <div className="max-w-2xl mx-auto space-y-6">
            <div>
              <h3 className="font-medium mb-2">What are your shipping times?</h3>
              <p className="text-gray-600">
                We typically process and ship orders within 1-2 business days. Delivery times vary by location.
              </p>
            </div>
            <div>
              <h3 className="font-medium mb-2">What is your return policy?</h3>
              <p className="text-gray-600">
                We offer free returns within 30 days of purchase for all unworn items with original tags.
              </p>
            </div>
            <div>
              <h3 className="font-medium mb-2">Do you ship internationally?</h3>
              <p className="text-gray-600">
                Yes, we ship to most countries worldwide. Shipping costs and times vary by location.
              </p>
            </div>
          </div>
        </div>
      </div>
    </main>
  );
};

export default Contact;