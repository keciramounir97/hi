import React from 'react';

const About = () => {
  return (
    <main className="pt-24 pb-16">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="max-w-3xl mx-auto text-center mb-12">
          <h1 className="text-4xl font-serif mb-4">Our Story</h1>
          <p className="text-gray-600">
            Crafting timeless elegance for the modern woman since 2015
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-12 mb-16">
          <div>
            <img
              src="https://images.unsplash.com/photo-1441984904996-e0b6ba687e04?q=80&w=2070"
              alt="Fashion atelier"
              className="w-full h-[500px] object-cover"
            />
          </div>
          <div className="flex flex-col justify-center">
            <h2 className="text-2xl font-serif mb-6">Our Mission</h2>
            <p className="text-gray-600 mb-6">
              At Jasmine Shop, we believe that every woman deserves to feel confident and beautiful in what she wears. Our mission is to create timeless pieces that combine elegant design with exceptional quality, ensuring that each garment becomes a cherished part of your wardrobe.
            </p>
            <p className="text-gray-600">
              We work with skilled artisans and use only the finest materials to craft our collections, paying meticulous attention to every detail. Our commitment to sustainable and ethical fashion practices ensures that you can feel good about your choices, knowing that your style doesn't compromise our values.
            </p>
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-8 mb-16">
          <div className="text-center">
            <div className="text-3xl font-serif text-green-800 mb-2">15k+</div>
            <p className="text-gray-600">Happy Customers</p>
          </div>
          <div className="text-center">
            <div className="text-3xl font-serif text-green-800 mb-2">100%</div>
            <p className="text-gray-600">Sustainable Materials</p>
          </div>
          <div className="text-center">
            <div className="text-3xl font-serif text-green-800 mb-2">50+</div>
            <p className="text-gray-600">Artisan Partners</p>
          </div>
        </div>

        <div className="bg-gray-50 p-12 text-center">
          <h2 className="text-2xl font-serif mb-6">Our Values</h2>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            <div>
              <h3 className="font-medium mb-2">Quality First</h3>
              <p className="text-gray-600">
                We never compromise on materials or craftsmanship
              </p>
            </div>
            <div>
              <h3 className="font-medium mb-2">Sustainable Fashion</h3>
              <p className="text-gray-600">
                Committed to ethical and eco-friendly practices
              </p>
            </div>
            <div>
              <h3 className="font-medium mb-2">Customer Focus</h3>
              <p className="text-gray-600">
                Your satisfaction is our top priority
              </p>
            </div>
          </div>
        </div>
      </div>
    </main>
  );
};

export default About;