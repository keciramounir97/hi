import React, { useState } from 'react';
import { Heart, Minus, Plus, Share2, Star } from 'lucide-react';
import Navbar from '../components/Navbar';
import Footer from '../components/Footer';

const product = {
  name: 'Silk Wrap Dress',
  price: 189.99,
  description: 'Elevate your wardrobe with our signature silk wrap dress. Crafted from premium silk fabric, this dress features a flattering wrap silhouette, delicate draping, and an adjustable waist tie. Perfect for both special occasions and elegant everyday wear.',
  images: [
    'https://images.unsplash.com/photo-1595777457583-95e059d581b8?q=80&w=1983',
    'https://images.unsplash.com/photo-1515372039744-b8f02a3ae446?q=80&w=1976',
    'https://images.unsplash.com/photo-1550639525-c97d455acf70?q=80&w=2026',
  ],
  sizes: ['XS', 'S', 'M', 'L', 'XL'],
  colors: ['Ivory', 'Black', 'Navy'],
  details: [
    'Premium silk fabric',
    'Adjustable wrap design',
    'Side pockets',
    'Lined bodice',
    'Made in Italy',
  ],
  care: [
    'Dry clean only',
    'Do not bleach',
    'Iron on low heat',
    'Store on padded hanger',
  ],
};

const Product = () => {
  const [selectedImage, setSelectedImage] = useState(0);
  const [quantity, setQuantity] = useState(1);

  return (
    <div className="min-h-screen">
      <Navbar />
      <main className="pt-16">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12">
            {/* Product Images */}
            <div className="space-y-4">
              <div className="aspect-[3/4] overflow-hidden">
                <img
                  src={product.images[selectedImage]}
                  alt={product.name}
                  className="w-full h-full object-cover"
                />
              </div>
              <div className="grid grid-cols-3 gap-4">
                {product.images.map((image, index) => (
                  <button
                    key={index}
                    className={`aspect-[3/4] overflow-hidden ${
                      selectedImage === index ? 'ring-2 ring-green-800' : ''
                    }`}
                    onClick={() => setSelectedImage(index)}
                  >
                    <img
                      src={image}
                      alt={`${product.name} ${index + 1}`}
                      className="w-full h-full object-cover"
                    />
                  </button>
                ))}
              </div>
            </div>

            {/* Product Info */}
            <div className="space-y-8">
              <div>
                <h1 className="text-3xl font-serif mb-2">{product.name}</h1>
                <p className="text-2xl text-green-800">${product.price}</p>
                <div className="flex items-center mt-2">
                  {[...Array(5)].map((_, i) => (
                    <Star
                      key={i}
                      className="h-5 w-5 text-yellow-400 fill-current"
                    />
                  ))}
                  <span className="ml-2 text-sm text-gray-500">
                    (128 reviews)
                  </span>
                </div>
              </div>

              <p className="text-gray-600">{product.description}</p>

              <div className="space-y-4">
                <div>
                  <h3 className="font-medium mb-2">Size</h3>
                  <div className="flex space-x-2">
                    {product.sizes.map((size) => (
                      <button
                        key={size}
                        className="w-12 h-12 border border-gray-200 flex items-center justify-center hover:border-green-800 focus:border-green-800 focus:outline-none"
                      >
                        {size}
                      </button>
                    ))}
                  </div>
                </div>

                <div>
                  <h3 className="font-medium mb-2">Color</h3>
                  <div className="flex space-x-2">
                    {product.colors.map((color) => (
                      <button
                        key={color}
                        className="px-4 py-2 border border-gray-200 hover:border-green-800 focus:border-green-800 focus:outline-none"
                      >
                        {color}
                      </button>
                    ))}
                  </div>
                </div>

                <div>
                  <h3 className="font-medium mb-2">Quantity</h3>
                  <div className="flex items-center space-x-4">
                    <button
                      className="p-2 border border-gray-200 hover:border-green-800"
                      onClick={() => setQuantity(Math.max(1, quantity - 1))}
                    >
                      <Minus className="h-4 w-4" />
                    </button>
                    <span className="w-12 text-center">{quantity}</span>
                    <button
                      className="p-2 border border-gray-200 hover:border-green-800"
                      onClick={() => setQuantity(quantity + 1)}
                    >
                      <Plus className="h-4 w-4" />
                    </button>
                  </div>
                </div>
              </div>

              <div className="flex space-x-4">
                <button className="flex-1 bg-green-800 text-white py-3 hover:bg-green-900 transition-colors">
                  Add to Cart
                </button>
                <button className="p-3 border border-gray-200 hover:border-green-800">
                  <Heart className="h-6 w-6" />
                </button>
                <button className="p-3 border border-gray-200 hover:border-green-800">
                  <Share2 className="h-6 w-6" />
                </button>
              </div>

              <div className="space-y-6 border-t border-gray-200 pt-8">
                <div>
                  <h3 className="font-serif text-lg mb-2">Product Details</h3>
                  <ul className="list-disc list-inside space-y-1 text-gray-600">
                    {product.details.map((detail, index) => (
                      <li key={index}>{detail}</li>
                    ))}
                  </ul>
                </div>

                <div>
                  <h3 className="font-serif text-lg mb-2">Care Instructions</h3>
                  <ul className="list-disc list-inside space-y-1 text-gray-600">
                    {product.care.map((instruction, index) => (
                      <li key={index}>{instruction}</li>
                    ))}
                  </ul>
                </div>
              </div>
            </div>
          </div>
        </div>
      </main>
      <Footer />
    </div>
  );
};

export default Product;