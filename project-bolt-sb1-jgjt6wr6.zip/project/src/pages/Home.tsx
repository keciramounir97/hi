import React from 'react';
import Hero from '../components/Hero';
import FeaturedCollections from '../components/FeaturedCollections';
import Newsletter from '../components/Newsletter';

const Home = () => {
  return (
    <main>
      <Hero />
      <FeaturedCollections />
      <Newsletter />
    </main>
  );
};

export default Home;