import React, { useState, useMemo } from 'react';
import Navbar from '../components/Navbar';
import Footer from '../components/Footer';
import FilterSidebar from '../components/FilterSidebar';
import ProductCard from '../components/ProductCard';

const products = [
  {
    id: '1',
    name: 'Silk Wrap Dress',
    price: 189.99,
    image: 'https://images.unsplash.com/photo-1595777457583-95e059d581b8?q=80&w=1983',
    category: 'Dresses',
    color: 'Beige',
    size: ['S', 'M', 'L'],
    isNew: true,
  },
  {
    id: '2',
    name: 'Classic White Blouse',
    price: 79.99,
    image: 'https://images.unsplash.com/photo-1434389677669-e08b4cac3105?q=80&w=2005',
    category: 'Tops',
    color: 'White',
    size: ['XS', 'S', 'M', 'L'],
  },
  {
    id: '3',
    name: 'Pleated Midi Skirt',
    price: 129.99,
    image: 'https://images.unsplash.com/photo-1583496661160-fb5886a0aaaa?q=80&w=1964',
    category: 'Skirts',
    color: 'Pink',
    size: ['S', 'M', 'L'],
    isNew: true,
  },
  {
    id: '4',
    name: 'Pearl Necklace',
    price: 59.99,
    image: 'https://images.unsplash.com/photo-1599643478518-a784e5dc4c8f?q=80&w=1974',
    category: 'Accessories',
    color: 'White',
    size: ['One Size'],
  },
  {
    id: '5',
    name: 'Evening Gown',
    price: 299.99,
    image: 'https://images.unsplash.com/photo-1566174053879-31528523f8ae?q=80&w=1938',
    category: 'Dresses',
    color: 'Black',
    size: ['XS', 'S', 'M', 'L', 'XL'],
  },
  {
    id: '6',
    name: 'Cashmere Sweater',
    price: 149.99,
    image: 'https://images.unsplash.com/photo-1576566588028-4147f3842f27?q=80&w=1964',
    category: 'Tops',
    color: 'Beige',
    size: ['S', 'M', 'L'],
    isNew: true,
  },
];

const Shop = () => {
  const [searchTerm, setSearchTerm] = useState('');
  const [sortBy, setSortBy] = useState('latest');
  const [selectedFilters, setSelectedFilters] = useState({
    categories: [],
    colors: [],
    sizes: [],
    priceRanges: [],
  });

  const handleSearch = (term: string) => {
    setSearchTerm(term);
  };

  const handleFilterChange = (type: string, items: string[]) => {
    setSelectedFilters(prev => ({
      ...prev,
      [type]: items,
    }));
  };

  const getPriceRange = (price: number) => {
    if (price < 50) return 'Under $50';
    if (price < 100) return '$50 - $100';
    if (price < 200) return '$100 - $200';
    return 'Over $200';
  };

  const filteredProducts = useMemo(() => {
    return products
      .filter(product => {
        const matchesSearch = product.name.toLowerCase().includes(searchTerm.toLowerCase());
        const matchesCategory = selectedFilters.categories.length === 0 || 
          selectedFilters.categories.includes(product.category);
        const matchesColor = selectedFilters.colors.length === 0 || 
          selectedFilters.colors.includes(product.color);
        const matchesSize = selectedFilters.sizes.length === 0 || 
          product.size.some(size => selectedFilters.sizes.includes(size));
        const matchesPriceRange = selectedFilters.priceRanges.length === 0 || 
          selectedFilters.priceRanges.includes(getPriceRange(product.price));

        return matchesSearch && matchesCategory && matchesColor && matchesSize && matchesPriceRange;
      })
      .sort((a, b) => {
        switch (sortBy) {
          case 'price-low':
            return a.price - b.price;
          case 'price-high':
            return b.price - a.price;
          case 'latest':
          default:
            return a.isNew ? -1 : 1;
        }
      });
  }, [searchTerm, selectedFilters, sortBy]);

  return (
    <div className="min-h-screen">
      <Navbar />
      <main className="pt-16">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
          <div className="flex justify-between items-center mb-8">
            <h1 className="text-3xl font-serif">Shop Collection</h1>
            <div className="flex items-center space-x-4">
              <span className="text-sm text-gray-500">
                Showing {filteredProducts.length} products
              </span>
              <select 
                className="border border-gray-200 rounded px-3 py-1 text-sm focus:outline-none focus:ring-2 focus:ring-green-800"
                value={sortBy}
                onChange={(e) => setSortBy(e.target.value)}
              >
                <option value="latest">Latest</option>
                <option value="price-low">Price: Low to High</option>
                <option value="price-high">Price: High to Low</option>
              </select>
            </div>
          </div>
          
          <div className="flex gap-8">
            <FilterSidebar 
              onSearch={handleSearch}
              onFilterChange={handleFilterChange}
              selectedFilters={selectedFilters}
            />
            <div className="flex-1">
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
                {filteredProducts.map((product) => (
                  <ProductCard key={product.id} {...product} />
                ))}
              </div>
              
              {filteredProducts.length === 0 && (
                <div className="text-center py-12">
                  <p className="text-gray-500">No products found matching your criteria.</p>
                </div>
              )}
            </div>
          </div>
        </div>
      </main>
      <Footer />
    </div>
  );
};

export default Shop;