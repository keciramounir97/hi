import React from 'react';
import { Trash2, Plus, Minus } from 'lucide-react';

const cartItems = [
  {
    id: '1',
    name: 'Silk Wrap Dress',
    price: 189.99,
    image: 'https://images.unsplash.com/photo-1595777457583-95e059d581b8?q=80&w=1983',
    quantity: 1,
    size: 'M',
    color: 'Ivory',
  },
  {
    id: '2',
    name: 'Classic White Blouse',
    price: 79.99,
    image: 'https://images.unsplash.com/photo-1434389677669-e08b4cac3105?q=80&w=2005',
    quantity: 2,
    size: 'S',
    color: 'White',
  },
];

const Cart = () => {
  const subtotal = cartItems.reduce((sum, item) => sum + item.price * item.quantity, 0);
  const shipping = 10;
  const total = subtotal + shipping;

  return (
    <main className="pt-24 pb-16">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <h1 className="text-3xl font-serif mb-8">Shopping Cart</h1>
        
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          <div className="lg:col-span-2">
            {cartItems.map((item) => (
              <div key={item.id} className="flex gap-6 py-6 border-b border-gray-200">
                <img
                  src={item.image}
                  alt={item.name}
                  className="w-24 h-32 object-cover"
                />
                <div className="flex-1">
                  <div className="flex justify-between mb-2">
                    <h3 className="font-medium">{item.name}</h3>
                    <button className="text-gray-400 hover:text-red-500">
                      <Trash2 className="h-5 w-5" />
                    </button>
                  </div>
                  <p className="text-gray-500 mb-2">Size: {item.size}</p>
                  <p className="text-gray-500 mb-4">Color: {item.color}</p>
                  <div className="flex justify-between items-center">
                    <div className="flex items-center space-x-2">
                      <button className="p-1 border border-gray-200 hover:border-green-800">
                        <Minus className="h-4 w-4" />
                      </button>
                      <span className="w-8 text-center">{item.quantity}</span>
                      <button className="p-1 border border-gray-200 hover:border-green-800">
                        <Plus className="h-4 w-4" />
                      </button>
                    </div>
                    <p className="font-medium">${(item.price * item.quantity).toFixed(2)}</p>
                  </div>
                </div>
              </div>
            ))}
          </div>
          
          <div className="lg:col-span-1">
            <div className="bg-gray-50 p-6">
              <h2 className="text-lg font-medium mb-4">Order Summary</h2>
              <div className="space-y-2 mb-4">
                <div className="flex justify-between">
                  <span>Subtotal</span>
                  <span>${subtotal.toFixed(2)}</span>
                </div>
                <div className="flex justify-between">
                  <span>Shipping</span>
                  <span>${shipping.toFixed(2)}</span>
                </div>
                <div className="border-t border-gray-200 pt-2 mt-2">
                  <div className="flex justify-between font-medium">
                    <span>Total</span>
                    <span>${total.toFixed(2)}</span>
                  </div>
                </div>
              </div>
              <button className="w-full bg-green-800 text-white py-3 hover:bg-green-900 transition-colors">
                Proceed to Checkout
              </button>
            </div>
          </div>
        </div>
      </div>
    </main>
  );
};

export default Cart;