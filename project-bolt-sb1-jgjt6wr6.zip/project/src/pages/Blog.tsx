import React from 'react';

const blogPosts = [
  {
    id: 1,
    title: 'Spring Fashion Trends 2024',
    excerpt: 'Discover the latest trends that will define this spring season, from pastel palettes to statement accessories.',
    image: 'https://images.unsplash.com/photo-1483985988355-763728e1935b?q=80&w=2070',
    category: 'Style Trends',
    date: 'March 15, 2024',
    author: 'Emma Style',
  },
  {
    id: 2,
    title: 'The Art of Capsule Wardrobe',
    excerpt: 'Learn how to build a versatile wardrobe with timeless pieces that mix and match perfectly.',
    image: 'https://images.unsplash.com/photo-1489987707025-afc232f7ea0f?q=80&w=2070',
    category: 'Style Guide',
    date: 'March 10, 2024',
    author: 'Sophie Ward',
  },
  {
    id: 3,
    title: 'Sustainable Fashion: A Better Future',
    excerpt: 'Explore how sustainable fashion choices can make a positive impact on our environment.',
    image: 'https://images.unsplash.com/photo-1581784368651-8916092072cf?q=80&w=2070',
    category: 'Sustainability',
    date: 'March 5, 2024',
    author: 'Olivia Green',
  },
];

const Blog = () => {
  return (
    <main className="pt-24 pb-16">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="max-w-3xl mx-auto text-center mb-12">
          <h1 className="text-4xl font-serif mb-4">The Style Journal</h1>
          <p className="text-gray-600">
            Fashion insights, styling tips, and the latest trends
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {blogPosts.map((post) => (
            <article key={post.id} className="group cursor-pointer">
              <div className="relative overflow-hidden mb-4">
                <img
                  src={post.image}
                  alt={post.title}
                  className="w-full h-64 object-cover transition-transform duration-500 group-hover:scale-105"
                />
              </div>
              <div className="space-y-2">
                <div className="flex items-center text-sm text-gray-500 space-x-4">
                  <span>{post.category}</span>
                  <span>•</span>
                  <span>{post.date}</span>
                </div>
                <h2 className="text-xl font-serif group-hover:text-green-800 transition-colors">
                  {post.title}
                </h2>
                <p className="text-gray-600">{post.excerpt}</p>
                <p className="text-sm text-gray-500">By {post.author}</p>
              </div>
            </article>
          ))}
        </div>

        <div className="mt-12 text-center">
          <button className="border border-green-800 text-green-800 px-8 py-2 hover:bg-green-800 hover:text-white transition-colors">
            Load More Articles
          </button>
        </div>

        <div className="mt-16 bg-gray-50 p-12 text-center">
          <h2 className="text-2xl font-serif mb-4">Subscribe to Our Newsletter</h2>
          <p className="text-gray-600 mb-6">
            Get the latest fashion tips and style inspiration delivered to your inbox
          </p>
          <form className="max-w-md mx-auto flex gap-2">
            <input
              type="email"
              placeholder="Enter your email"
              className="flex-1 border border-gray-200 p-2 focus:outline-none focus:ring-2 focus:ring-green-800"
            />
            <button
              type="submit"
              className="bg-green-800 text-white px-6 py-2 hover:bg-green-900 transition-colors"
            >
              Subscribe
            </button>
          </form>
        </div>
      </div>
    </main>
  );
};

export default Blog;