import React from 'react';

const Newsletter = () => {
  return (
    <section className="bg-green-800 py-16">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center">
          <h2 className="text-3xl font-serif text-white mb-4">Join Our Newsletter</h2>
          <p className="text-green-100 mb-8">
            Subscribe to receive updates on new collections and exclusive offers
          </p>
          <div className="max-w-md mx-auto">
            <form className="flex gap-2">
              <input
                type="email"
                placeholder="Enter your email"
                className="flex-1 px-4 py-2 rounded-none focus:outline-none focus:ring-2 focus:ring-green-900"
              />
              <button
                type="submit"
                className="bg-white text-green-800 px-6 py-2 rounded-none hover:bg-green-100 transition-colors"
              >
                Subscribe
              </button>
            </form>
          </div>
        </div>
      </div>
    </section>
  );
};

export default Newsletter;