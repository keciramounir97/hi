import React, { useState } from 'react';
import { ChevronDown, Search } from 'lucide-react';

const categories = ['All', 'Dresses', 'Tops', 'Skirts', 'Accessories'];
const colors = ['Black', 'White', 'Beige', 'Pink', 'Green'];
const sizes = ['XS', 'S', 'M', 'L', 'XL'];
const priceRanges = ['Under $50', '$50 - $100', '$100 - $200', 'Over $200'];

interface FilterSectionProps {
  title: string;
  items: string[];
  selectedItems: string[];
  onItemSelect: (item: string) => void;
}

const FilterSection: React.FC<FilterSectionProps> = ({ 
  title, 
  items, 
  selectedItems, 
  onItemSelect 
}) => {
  const [isOpen, setIsOpen] = useState(true);

  return (
    <div className="border-b border-gray-200 py-4">
      <button 
        className="flex items-center justify-between w-full mb-2"
        onClick={() => setIsOpen(!isOpen)}
      >
        <span className="font-medium">{title}</span>
        <ChevronDown className={`h-4 w-4 transform transition-transform ${isOpen ? 'rotate-180' : ''}`} />
      </button>
      {isOpen && (
        <div className="space-y-2">
          {items.map((item) => (
            <label key={item} className="flex items-center space-x-2">
              <input 
                type="checkbox" 
                checked={selectedItems.includes(item)}
                onChange={() => onItemSelect(item)}
                className="rounded border-gray-300 text-green-800 focus:ring-green-800" 
              />
              <span className="text-sm">{item}</span>
            </label>
          ))}
        </div>
      )}
    </div>
  );
};

interface FilterSidebarProps {
  onSearch: (term: string) => void;
  onFilterChange: (type: string, items: string[]) => void;
  selectedFilters: {
    categories: string[];
    colors: string[];
    sizes: string[];
    priceRanges: string[];
  };
}

const FilterSidebar: React.FC<FilterSidebarProps> = ({ 
  onSearch, 
  onFilterChange,
  selectedFilters 
}) => {
  const [searchTerm, setSearchTerm] = useState('');

  const handleSearch = (e: React.ChangeEvent<HTMLInputElement>) => {
    const term = e.target.value;
    setSearchTerm(term);
    onSearch(term);
  };

  const handleFilterSelect = (type: string, item: string) => {
    const currentSelected = selectedFilters[type as keyof typeof selectedFilters];
    const newSelected = currentSelected.includes(item)
      ? currentSelected.filter(i => i !== item)
      : [...currentSelected, item];
    onFilterChange(type, newSelected);
  };

  return (
    <div className="w-64 pr-8">
      <div className="mb-6">
        <div className="relative">
          <input
            type="text"
            placeholder="Search products..."
            value={searchTerm}
            onChange={handleSearch}
            className="w-full pl-10 pr-4 py-2 border border-gray-200 rounded-md focus:outline-none focus:ring-2 focus:ring-green-800"
          />
          <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-gray-400" />
        </div>
      </div>

      <h2 className="text-xl font-serif mb-6">Filters</h2>
      
      <FilterSection 
        title="Category" 
        items={categories}
        selectedItems={selectedFilters.categories}
        onItemSelect={(item) => handleFilterSelect('categories', item)}
      />
      <FilterSection 
        title="Color" 
        items={colors}
        selectedItems={selectedFilters.colors}
        onItemSelect={(item) => handleFilterSelect('colors', item)}
      />
      <FilterSection 
        title="Size" 
        items={sizes}
        selectedItems={selectedFilters.sizes}
        onItemSelect={(item) => handleFilterSelect('sizes', item)}
      />
      <FilterSection 
        title="Price" 
        items={priceRanges}
        selectedItems={selectedFilters.priceRanges}
        onItemSelect={(item) => handleFilterSelect('priceRanges', item)}
      />
    </div>
  );
};

export default FilterSidebar;