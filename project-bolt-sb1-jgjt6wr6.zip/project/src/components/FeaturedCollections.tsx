import React from 'react';

const collections = [
  {
    id: 1,
    title: 'New Arrivals',
    image: 'https://images.unsplash.com/photo-1485968579580-b6d095142e6e?q=80&w=2070',
    description: 'Discover our latest pieces'
  },
  {
    id: 2,
    title: 'Best Sellers',
    image: 'https://images.unsplash.com/photo-1483985988355-763728e1935b?q=80&w=2070',
    description: 'Shop our most loved styles'
  },
  {
    id: 3,
    title: 'Limited Edition',
    image: 'https://images.unsplash.com/photo-1469334031218-e382a71b716b?q=80&w=2070',
    description: 'Exclusive pieces for unique style'
  }
];

const FeaturedCollections = () => {
  return (
    <section className="py-16 bg-gray-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <h2 className="text-3xl font-serif text-center text-gray-900 mb-12">Featured Collections</h2>
        
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          {collections.map((collection) => (
            <div key={collection.id} className="group cursor-pointer">
              <div className="relative overflow-hidden">
                <img
                  src={collection.image}
                  alt={collection.title}
                  className="w-full h-96 object-cover transition-transform duration-500 group-hover:scale-105"
                />
                <div className="absolute inset-0 bg-black bg-opacity-20 transition-opacity duration-500 group-hover:bg-opacity-30"></div>
                <div className="absolute inset-0 flex items-center justify-center">
                  <div className="text-center">
                    <h3 className="text-2xl font-serif text-white mb-2">{collection.title}</h3>
                    <p className="text-white">{collection.description}</p>
                  </div>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default FeaturedCollections;