import React, { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { ShoppingBag, Heart, Search, Menu, User, X } from 'lucide-react';

const Navbar = () => {
  const [isSidebarOpen, setIsSidebarOpen] = useState(false);
  const navigate = useNavigate();

  return (
    <>
      <nav className="fixed w-full bg-white/95 backdrop-blur-sm z-50 border-b border-gray-100">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center h-16">
            <div className="flex items-center">
              <button 
                className="lg:hidden p-2"
                onClick={() => setIsSidebarOpen(true)}
              >
                <Menu className="h-6 w-6 text-gray-700" />
              </button>
              <div className="hidden lg:flex items-center space-x-8 ml-8">
                <Link to="/shop" className="text-gray-700 hover:text-green-800">New Arrivals</Link>
                <Link to="/shop" className="text-gray-700 hover:text-green-800">Clothing</Link>
                <Link to="/shop" className="text-gray-700 hover:text-green-800">Accessories</Link>
                <Link to="/shop" className="text-gray-700 hover:text-green-800">Collections</Link>
              </div>
            </div>

            <Link to="/" className="text-2xl font-serif text-green-800">Jasmine Shop</Link>

            <div className="flex items-center space-x-4">
              <button className="p-2">
                <Search className="h-5 w-5 text-gray-700" />
              </button>
              <button className="p-2">
                <User className="h-5 w-5 text-gray-700" />
              </button>
              <button className="p-2">
                <Heart className="h-5 w-5 text-gray-700" />
              </button>
              <button className="p-2 relative" onClick={() => navigate('/cart')}>
                <ShoppingBag className="h-5 w-5 text-gray-700" />
                <span className="absolute top-0 right-0 h-4 w-4 bg-green-800 text-white text-xs rounded-full flex items-center justify-center">
                  0
                </span>
              </button>
            </div>
          </div>
        </div>
      </nav>

      {/* Mobile Sidebar */}
      <div 
        className={`fixed inset-0 bg-black bg-opacity-50 z-50 transition-opacity duration-300 ${
          isSidebarOpen ? 'opacity-100' : 'opacity-0 pointer-events-none'
        }`}
        onClick={() => setIsSidebarOpen(false)}
      >
        <div 
          className={`fixed inset-y-0 left-0 w-64 bg-white transform transition-transform duration-300 ease-in-out ${
            isSidebarOpen ? 'translate-x-0' : '-translate-x-full'
          }`}
          onClick={e => e.stopPropagation()}
        >
          <div className="p-6">
            <div className="flex justify-between items-center mb-8">
              <span className="text-xl font-serif text-green-800">Menu</span>
              <button 
                className="p-2"
                onClick={() => setIsSidebarOpen(false)}
              >
                <X className="h-6 w-6 text-gray-700" />
              </button>
            </div>
            <div className="space-y-6">
              <Link to="/shop" className="block text-gray-700 hover:text-green-800" onClick={() => setIsSidebarOpen(false)}>New Arrivals</Link>
              <Link to="/shop" className="block text-gray-700 hover:text-green-800" onClick={() => setIsSidebarOpen(false)}>Clothing</Link>
              <Link to="/shop" className="block text-gray-700 hover:text-green-800" onClick={() => setIsSidebarOpen(false)}>Accessories</Link>
              <Link to="/shop" className="block text-gray-700 hover:text-green-800" onClick={() => setIsSidebarOpen(false)}>Collections</Link>
              <hr className="border-gray-200" />
              <Link to="/about" className="block text-gray-700 hover:text-green-800" onClick={() => setIsSidebarOpen(false)}>About Us</Link>
              <Link to="/contact" className="block text-gray-700 hover:text-green-800" onClick={() => setIsSidebarOpen(false)}>Contact</Link>
              <Link to="/blog" className="block text-gray-700 hover:text-green-800" onClick={() => setIsSidebarOpen(false)}>Blog</Link>
            </div>
          </div>
        </div>
      </div>
    </>
  );
};

export default Navbar;