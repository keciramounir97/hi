import React from 'react';
import { Heart } from 'lucide-react';

interface ProductCardProps {
  id: string;
  name: string;
  price: number;
  image: string;
  category: string;
  isNew?: boolean;
}

const ProductCard: React.FC<ProductCardProps> = ({ name, price, image, category, isNew }) => {
  return (
    <div className="group cursor-pointer">
      <div className="relative overflow-hidden">
        <img
          src={image}
          alt={name}
          className="w-full h-[400px] object-cover transition-transform duration-500 group-hover:scale-105"
        />
        {isNew && (
          <span className="absolute top-4 left-4 bg-green-800 text-white px-3 py-1 text-sm">
            New Arrival
          </span>
        )}
        <button className="absolute top-4 right-4 p-2 bg-white/90 rounded-full opacity-0 group-hover:opacity-100 transition-opacity duration-300">
          <Heart className="h-5 w-5 text-gray-700" />
        </button>
        <div className="absolute bottom-0 left-0 right-0 bg-white/90 p-4 translate-y-full group-hover:translate-y-0 transition-transform duration-300">
          <button className="w-full bg-green-800 text-white py-2 hover:bg-green-900 transition-colors">
            Quick View
          </button>
        </div>
      </div>
      <div className="mt-4 space-y-1">
        <p className="text-sm text-gray-500 uppercase">{category}</p>
        <h3 className="font-medium">{name}</h3>
        <p className="text-green-800">${price.toFixed(2)}</p>
      </div>
    </div>
  );
};

export default ProductCard;