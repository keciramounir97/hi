import React from 'react';
import { Facebook, Instagram, Twitter, Phone } from 'lucide-react';

const Footer = () => {
  return (
    <footer className="bg-gray-900 text-gray-300">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
          <div>
            <h3 className="text-xl font-serif text-white mb-4">Jasmine Shop</h3>
            <p className="text-sm">
              Elegant fashion for the modern woman. Timeless pieces that empower and inspire.
            </p>
          </div>
          
          <div>
            <h4 className="text-white mb-4">Shop</h4>
            <ul className="space-y-2">
              <li><a href="#" className="hover:text-white">New Arrivals</a></li>
              <li><a href="#" className="hover:text-white">Best Sellers</a></li>
              <li><a href="#" className="hover:text-white">Collections</a></li>
              <li><a href="#" className="hover:text-white">Sale</a></li>
            </ul>
          </div>
          
          <div>
            <h4 className="text-white mb-4">Help</h4>
            <ul className="space-y-2">
              <li><a href="#" className="hover:text-white">Contact Us</a></li>
              <li><a href="#" className="hover:text-white">Shipping</a></li>
              <li><a href="#" className="hover:text-white">Returns</a></li>
              <li><a href="#" className="hover:text-white">Size Guide</a></li>
            </ul>
          </div>
          
          <div>
            <h4 className="text-white mb-4">Connect</h4>
            <div className="flex flex-col space-y-4">
              <a href="https://www.facebook.com/Jasminshop96" target="_blank" rel="noopener noreferrer" className="hover:text-white flex items-center space-x-2">
                <Facebook className="h-5 w-5" />
                <span>Jasminshop96</span>
              </a>
              <a href="https://www.instagram.com/jasmine_shop_96" target="_blank" rel="noopener noreferrer" className="hover:text-white flex items-center space-x-2">
                <Instagram className="h-5 w-5" />
                <span>@jasmine_shop_96</span>
              </a>
              <a href="https://wa.me/213657525137" target="_blank" rel="noopener noreferrer" className="hover:text-white flex items-center space-x-2">
                <Phone className="h-5 w-5" />
                <span>+213 657 52 51 37</span>
              </a>
            </div>
          </div>
        </div>
        
        <div className="border-t border-gray-800 mt-12 pt-8 text-sm text-center">
          <p>&copy; 2024 Jasmine Shop. All rights reserved.</p>
        </div>
      </div>
    </footer>
  );
};

export default Footer;